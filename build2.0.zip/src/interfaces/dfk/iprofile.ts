
export interface DfkProfile {
    id: string;
    address: string;
    name: string;
    creationTime: string;
    picId: string;
    heroId: string;
    points: string;
}