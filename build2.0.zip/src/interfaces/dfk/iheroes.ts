

export interface HeroList {
    heroes?: number[];
}