const config = require("../../../config.json");
/*
export enum RpcTypes {
    Primary,
    Backup
}

export default class RpcHandler {
    public getRpc(type: RpcTypes) {
        return type === RpcTypes.Primary ? config.rpc.primaryRpc : config.rpc.backupRpc;
    }
}
 */